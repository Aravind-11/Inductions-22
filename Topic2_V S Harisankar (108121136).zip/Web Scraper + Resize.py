import os, sys

import requests
import splitfolders as sf
from bs4 import BeautifulSoup
from PIL import Image


def ImageScraper(url, folder):
    try:
        os.mkdir(os.path.join(os.getcwd(), folder))
    except:
        pass
    os.chdir(os.path.join(os.getcwd(), folder))
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html.parser')
    images = soup.find_all('img')

    name = 0
    print(type(images))
    images_new = images[1:]
    print(len(images_new))
    for image in images_new:
        name = name + 1
        link = image['src']
        img = Image.open(requests.get(link, stream = True).raw)
        img.save(str(name) + '.jpg')
        print('Writing: ', name)

#ImageScraper('https://www.google.com/search?sxsrf=ALiCzsYNC4Wf9tr9lcUCYm4KkyYSqamnQA:1668445226143&source=univ&tbm=isch&q=natasha+romanoff+winter+soldier+images&hl=en&client=safari&fir=LybWHob47r2QfM%252C0nGYisRLqXwmzM%252C_%253B_55Pkj9oIYiv7M%252Cs6EE660UVdROiM%252C_%253Bu2iqd6jVvpYGXM%252Clfafc4hN7fBuOM%252C_%253BktKtI7AqXPTSLM%252C2FmpNmCBZct1JM%252C_%253Bo0jBTppiowBaZM%252CFuZmv5_OmoJ0FM%252C_%253BcbXVKzow07tMFM%252CIO4N8Hqz35CJPM%252C_%253BWEzsGrls66TnnM%252CS_jq6bhH-9PjhM%252C_%253BU0lkJf5hhtFO3M%252CBxnELGbiy1pvjM%252C_%253BmqstdzEMnMUbFM%252CVeZT-4lVFtyYlM%252C_%253BdEdWge0hnkFQpM%252CFmpvLqeEsExvjM%252C_&usg=AI4_-kR_HYNML5TyKKdhvIRg01b8lRDAKQ&sa=X&ved=2ahUKEwjT85_okq77AhXOFogKHS7dDQAQ7Al6BAgIEFA&biw=1470&bih=840&dpr=2', 'Black Widow2')
input_folder = '/Users/hari/Documents/Python Files/Databyte/Avengers_dataset'
sf.ratio(input_folder, output = 'dataset', seed = 12, ratio = (0.8, 0.2))


def resize(path):
    dirs = os.listdir( path )
    for item in dirs:
        if os.path.isfile(path+item):
            im = Image.open(path+item)
            f, e = os.path.splitext(path+item)
            imResize = im.resize((128,128), Image.ANTIALIAS)
            imResize.save(f + ' resized.jpg', 'JPEG', quality=100)
            print(imResize.size)
